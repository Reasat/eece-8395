clear all
close all
clc
img=ReadNrrd('..\..\Data\0522c0001\img.nrrd');
% 1-> axial
% 2-> saggital
% 3-> coronal
% DisplayVolume(img,1,56)
DisplayVolume(img,1,56)
% DisplayVolume(img,3,256)