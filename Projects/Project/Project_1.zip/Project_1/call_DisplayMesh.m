clear all
close all
clc

load ..\..\Data\0522c0001\structures\BrainStem.mat
DisplayMesh(M,[0,0,1],0.2)