function res = IsNodeMarked(node)
global Done;
res = Done(node);
return;