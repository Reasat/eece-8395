function SetPointer(node,prev)
global Pointer;
Pointer(node) = prev;
return;