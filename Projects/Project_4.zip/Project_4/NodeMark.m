function NodeMark(node)
global Done;
Done(node) = 1;
return;