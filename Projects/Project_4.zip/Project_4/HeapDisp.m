function HeapDisp
global heap
heap.q(:,1:heap.len)