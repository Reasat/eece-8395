function prev = GetPointer(node)
global Pointer;
prev = Pointer(node);
return;